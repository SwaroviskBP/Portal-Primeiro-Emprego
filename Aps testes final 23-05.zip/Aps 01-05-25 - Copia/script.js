//scprit carrossel//
let atual = 0;
const slides = document.querySelectorAll('.carousel-inner img');

function mostrarSlide(n) {
  slides.forEach(slide => slide.classList.remove('active'));
  slides[n].classList.add('active');
}

document.querySelector('.prev').addEventListener('click', () => {
  atual = (atual - 1 + slides.length) % slides.length;
  mostrarSlide(atual);
});

document.querySelector('.next').addEventListener('click', () => {
  atual = (atual + 1) % slides.length;
  mostrarSlide(atual);
});

mostrarSlide(atual);
setInterval(() => {
  atual = (atual + 1) % slides.length;
  mostrarSlide(atual);
}, 8000);

//scprit modal//
document.querySelectorAll('.curriculo-img').forEach(img => {
  img.addEventListener('click', function() {
    document.getElementById('modal').style.display = "block";
    document.getElementById('img-modal').src = this.src;
  });
});

document.querySelector('.fechar-modal').addEventListener('click', function() {
  document.getElementById('modal').style.display = "none";
});

window.addEventListener('click', function(event) {
  let modal = document.getElementById('modal');
  if (event.target == modal) {
    modal.style.display = "none";
  }
});
